export interface Subcategoria {
    _id?:string;
    codigo?:string;
    descripcion?: string;
}