export interface Archivo {
    _id?:string;
    nombre?:string;
}