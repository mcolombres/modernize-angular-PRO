import { Component } from '@angular/core';

@Component({
    selector: 'app-disposiciones',
    templateUrl: './disposiciones.component.html',
    //styleUrls: ['./disposiciones.component.css']
})
export class AppDisposicionesComponent  {

    constructor() { }


}